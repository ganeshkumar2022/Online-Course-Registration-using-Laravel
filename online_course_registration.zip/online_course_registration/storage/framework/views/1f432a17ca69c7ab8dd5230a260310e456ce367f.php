<?php $__env->startSection('title','Online Course Registration - Student | View Enroll page'); ?>

<!-- header start  -->
<?php echo $__env->make('layouts.student_header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<!-- header end -->

<!-- main content start -->
<?php $__env->startSection('main-content'); ?>
<div class="home-content">
<div class="container">
    <h3 class="text-primary">Enroll History</h3>
    <p style="border-bottom:4px solid rgb(13,110,253);" class="mt-3 bg-primary">
    <div class="row">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header bg-info">Enroll History</div>
                <div class="card-body">
                <table class="table table-bordered">
                    <tr class="table-primary">
                        <th>S.No</th>
                        <th>Course Name</th>
                        <th>Session</th>
                        <th>Department</th>
                        <th>Level</th>
                        <th>Semester</th>
                        <th>Enrollment Date</th>
                        <th>Action</th>
                    </tr>
                    <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sno=>$row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($sno+1); ?></td>
                        <td><?php echo e($row->course_name); ?></td>
                        <td><?php echo e($row->session_name); ?></td>
                        <td><?php echo e($row->department_name); ?></td>
                        <td><?php echo e($row->level_id); ?></td>
                        <td><?php echo e($row->semester_name); ?></td>
                        <td><?php echo e($row->created_at); ?></td>
                        <td>
                            <a href="<?php echo e(route('student.print_fun',$row->id)); ?>" class="btn btn-success"><i class="fa-solid fa-print"></i> Print</a>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php if(count($data)==0): ?>
                    <tr>
                        <td colspan="7">No records found</td>
                    </tr>
                    <?php endif; ?>
                </table>

            </div>
        </div>
        </div>
    </div>

</div>
</div>
<?php $__env->stopSection(); ?>

<script src="https://code.jquery.com/jquery-3.7.1.js"></script>
<script>
     $(document).ready(function(){
    $(document).on('submit', '#manage_course', function(e) {
    var a=confirm("Are you sure you want to Delete :");
    if(a)
    {
        return true;
    }
    else
    {
    alert('Cancelled successfully');
    e.preventDefault();
    }
     });
});
function number_only_accept(event) {


if (event.keyCode < 48 || event.keyCode > 57) {
    event.preventDefault();
}
}

</script>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\personal\projects\online_course_registration\resources\views/student/view_enroll.blade.php ENDPATH**/ ?>
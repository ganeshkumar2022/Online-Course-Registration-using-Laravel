<?php $__env->startSection('title','Online Course Registration - Admin | view session page'); ?>

<!-- header start  -->
<?php echo $__env->make('layouts.admin_header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<!-- header end -->

<!-- main content start -->
<?php $__env->startSection('main-content'); ?>
<div class="home-content">
<div class="container">
    <h3 class="text-primary">Add Department</h3>
    <p style="border-bottom:4px solid rgb(13,110,253);" class="mt-3 bg-primary">
    <div class="row">
        <div class="col-md-6 offset-3">
            <div class="card">
                <div class="card-header bg-info">Department</div>
                <div class="card-body">
            <form action="<?php echo e(route('admin.add_department')); ?>" method="POST" autocomplete="off">
              <?php echo csrf_field(); ?>
                <div class="mb-3">
                  <label for="department_name" class="form-label">Department:</label>
                  <input type="text" class="form-control" value="<?php echo e(old('department_name')); ?>" id="department_name" placeholder="Enter Department" name="department_name">
                  <span class="text-danger"><?php echo e($errors->first('department_name')); ?></span>
                </div>
                <button type="submit" class="btn btn-primary"><i class="fa-solid fa-circle-plus"></i> Create</button>
              </form>

            </div>
        </div>
        </div>
    </div>
    <div class="col-md-12 mt-4">
        <div class="card">
        <div class="card-header">Manage Department</div>
        <div class="card-body">
            <table class="table table-bordered">
                <tr class="table-primary">
                    <th>S.No</th>
                    <th>Department Name</th>
                    <th>Creation Date</th>
                    <th>Action</th>
                </tr>
                <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sno=>$row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($sno+1); ?></td>
                    <td><?php echo e($row->department_name); ?></td>
                    <td><?php echo e($row->created_at); ?></td>
                    <td>
                        <form method="post" id="manage_department" action="<?php echo e(route('admin.delete_department',$row->id)); ?>">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <button type="submit" name="delete" class="btn del_btn btn-danger btn-sm"><i class="fa-solid fa-trash"></i> Delete</button>
                        </form>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php if(count($data)==0): ?>
                <tr>
                    <td colspan="4">No records found</td>
                </tr>
                <?php endif; ?>
            </table>
        </div>
    </div>
</div>
</div>
</div>
<?php $__env->stopSection(); ?>

<script src="https://code.jquery.com/jquery-3.7.1.js"></script>
<script>
     $(document).ready(function(){
    $(document).on('submit', '#manage_department', function(e) {
    var a=confirm("Are you sure you want to Delete :");
    if(a)
    {
        return true;
    }
    else
    {
    alert('Cancelled successfully');
    e.preventDefault();
    }
     });
});


</script>


<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\personal\projects\online_course_registration\resources\views/admin/view_department.blade.php ENDPATH**/ ?>
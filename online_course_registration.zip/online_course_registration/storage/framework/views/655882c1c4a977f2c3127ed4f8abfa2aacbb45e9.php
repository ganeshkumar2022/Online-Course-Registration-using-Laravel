<?php $__env->startSection('title','Online Course Registration - Home page'); ?>

<!-- header start  -->
<?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<!-- header end -->

<!-- main content start -->
<?php $__env->startSection('main-content'); ?>
<div class="home-content">
<div class="container">
    <div class="row">
        <div class="col-md-6">
            <form action="<?php echo e(route('verify_admin_login')); ?>" method="POST" autocomplete="off">
              <?php echo csrf_field(); ?>
                <h3 class="text-primary">Admin Login</h3>
                <p style="border-bottom:4px solid rgb(13,110,253);" class="mt-3 bg-primary">
                <div class="mb-3 mt-3">
                  <label for="email" class="form-label">Enter Email:</label>
                  <input type="text" class="form-control" value="<?php echo e(old('email')); ?>" id="email" placeholder="Enter email" name="email">
                  <span class="text-danger"><?php echo e($errors->first('email')); ?></span>
                </div>
                <div class="mb-3">
                  <label for="password" class="form-label">Enter Password:</label>
                  <input type="password" class="form-control" value="<?php echo e(old('password')); ?>" id="password" placeholder="Enter password" name="password">
                  <span class="text-danger"><?php echo e($errors->first('password')); ?></span>
                </div>
                <button type="submit" class="btn btn-primary"><i class="fa-solid fa-user"></i> Login</button>
              </form>
        </div>
        <div class="col-md-6">
            <img src="<?php echo e(asset('assets/images/admin.jpg')); ?>" class="img-fluid">
        </div>
    </div>
</div>
</div>
<?php $__env->stopSection(); ?>
<!-- main content end -->



<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\personal\projects\online_course_registration\resources\views/admin_login.blade.php ENDPATH**/ ?>
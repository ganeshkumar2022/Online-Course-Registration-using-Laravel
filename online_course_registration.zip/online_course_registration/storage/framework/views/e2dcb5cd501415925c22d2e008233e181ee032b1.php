<?php $__env->startSection('title','Online Course Registration - Admin | Dashboard page'); ?>

<!-- header start  -->
<?php echo $__env->make('layouts.admin_header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<!-- header end -->

<!-- main content start -->
<?php $__env->startSection('main-content'); ?>
<div class="home-content">
<div class="container">
    <h3 class="text-primary">Admin Change Password</h3>
    <p style="border-bottom:4px solid rgb(13,110,253);" class="mt-3 bg-primary">
    <div class="row">
        <div class="col-md-6 offset-3">
            <div class="card">
                <div class="card-header bg-info">Change Password</div>
                <div class="card-body">
            <form action="<?php echo e(route('admin.update_password')); ?>" method="POST" autocomplete="off">
              <?php echo csrf_field(); ?>
              <?php echo method_field('PUT'); ?>
                <div class="mb-3">
                  <label for="current_password" class="form-label">Current Password:</label>
                  <input type="password" class="form-control" value="<?php echo e(old('current_password')); ?>" id="current_password" placeholder="Enter Current password" name="current_password">
                  <span class="text-danger"><?php echo e($errors->first('current_password')); ?></span>
                </div>
                <div class="mb-3">
                    <label for="new_password" class="form-label">New Password:</label>
                    <input type="password" class="form-control" value="<?php echo e(old('new_password')); ?>" id="new_password" placeholder="Enter New password" name="new_password">
                    <span class="text-danger"><?php echo e($errors->first('new_password')); ?></span>
                  </div>
                  <div class="mb-3">
                    <label for="confirm_password" class="form-label">Confirm Password:</label>
                    <input type="password" class="form-control" value="<?php echo e(old('confirm_password')); ?>" id="confirm_password" placeholder="Enter Confirm password" name="confirm_password">
                    <span class="text-danger"><?php echo e($errors->first('confirm_password')); ?></span>
                  </div>
                <button type="submit" class="btn btn-primary"><i class="fa-solid fa-user"></i> Update</button>
              </form>

            </div>
        </div>
        </div>
    </div>
</div>
</div>
<?php $__env->stopSection(); ?>
<!-- main content end -->



<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\personal\projects\online_course_registration\resources\views/admin/dashboard.blade.php ENDPATH**/ ?>
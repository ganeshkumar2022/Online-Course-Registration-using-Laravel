<?php $__env->startSection('title','Online Course Registration - Home page'); ?>

<!-- header start  -->
<?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<!-- header end -->

<!-- main content start -->
<?php $__env->startSection('main-content'); ?>
<div class="home-content">
<div class="container">
    <div class="row">
        <div class="col-md-6">
            <form action="<?php echo e(route('verify_student_login')); ?>" method="POST" autocomplete="off">
              <?php echo csrf_field(); ?>
                <h3 class="text-primary">Student Login</h3>
                <p style="border-bottom:4px solid rgb(13,110,253);" class="mt-3 bg-primary">
                <div class="mb-3 mt-3">
                  <label for="reg_no" class="form-label">Enter Reg no:</label>
                  <input type="text" class="form-control" value="<?php echo e(old('reg_no')); ?>" id="reg_no" placeholder="Enter Reg no" name="reg_no">
                  <span class="text-danger"><?php echo e($errors->first('reg_no')); ?></span>
                </div>
                <div class="mb-3">
                  <label for="password" class="form-label">Enter Password:</label>
                  <input type="password" class="form-control" value="<?php echo e(old('password')); ?>" id="password" placeholder="Enter password" name="password">
                  <span class="text-danger"><?php echo e($errors->first('password')); ?></span>
                </div>
                <button type="submit" class="btn btn-primary"><i class="fa-solid fa-user"></i> Login</button>
              </form>
        </div>
        <div class="col-md-6">
           <div class="alert alert-success mt-3">
            <h3>Latest News / Update</h3>
            <marquee direction="up">
            <ul>
                <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><b><?php echo e($row->news_title); ?>:</b> <?php echo e($row->news_description); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </marquee>
           </div>
        </div>
    </div>
</div>
</div>
<?php $__env->stopSection(); ?>
<!-- main content end -->



<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\personal\projects\online_course_registration\resources\views/student_login.blade.php ENDPATH**/ ?>
<?php $__env->startSection('title','Online Course Registration - Student | View Enroll page'); ?>



<!-- main content start -->
<?php $__env->startSection('main-content'); ?>
<div class="home-content">
<div class="container">

    <div class="row">
        <div class="col-md-12">
            <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="card">
                <div class="card-body">
                    <div class="row">
                        <div class="col-md-6">
                            <img src="<?php echo e(asset('enroll_images/'.$row->image_path)); ?>" style="height:200px;width:200px;">
                        </div>
                        <div class="col-md-6">
                            <ul class="list-unstyled float-end text-end mt-4">
                                <li><b>Regno :</b> <?php echo e($student->reg_no); ?></li>
                                <li><b>Student Name :</b> <?php echo e($student->student_name); ?></li>
                                <li><b>Student Reg Date :</b> <?php echo e($student->created_at); ?></li>
                                <li><b>Student Course Enroll Date :</b> <?php echo e($row->created_at); ?></li>
                            </ul>
                        </div>
                        <div class="col-md-12">
                            <table class="table mt-3">
                                <tr class="table-secondary">
                                    <th colspan="2">Course Details</th>
                                </tr>
                                <tr>
                                    <td>Course Code</td>
                                    <td><span class="float-end"><?php echo e($row->course_code); ?></span></td>
                                </tr>
                                <tr>
                                    <td>Course Name</td>
                                    <td><span class="float-end"><?php echo e($row->course_name); ?></span></td>
                                </tr>
                                <tr>
                                    <td>Course Unit</td>
                                    <td><span class="float-end"><?php echo e($row->course_unit); ?></span></td>
                                </tr>
                            </table>

                            <table class="table mt-3">
                                <tr class="table-secondary">
                                    <th colspan="2">Other Details</th>
                                </tr>
                                <tr>
                                    <td>Session</td>
                                    <td><span class="float-end"><?php echo e($row->session_name); ?></span></td>
                                </tr>
                                <tr>
                                    <td>Department Name</td>
                                    <td><span class="float-end"><?php echo e($row->department_name); ?></span></td>
                                </tr>
                                <tr>
                                    <td>Level</td>
                                    <td><span class="float-end"><?php echo e($row->level_id); ?></span></td>
                                </tr>
                                <tr>
                                    <td>CGPA</td>
                                    <td><span class="float-end"></span></td>
                                </tr>
                                <tr>
                                    <td>Semester</td>
                                    <td><span class="float-end"><?php echo e($row->semester_name); ?></span></td>
                                </tr>
                            </table>
                        </div>
                    </div>
                </div>
            </div>

            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>

</div>
</div>
<?php $__env->stopSection(); ?>

<script src="https://code.jquery.com/jquery-3.7.1.js"></script>
<script>
     $(document).ready(function(){
    $(document).on('submit', '#manage_course', function(e) {
    var a=confirm("Are you sure you want to Delete :");
    if(a)
    {
        return true;
    }
    else
    {
    alert('Cancelled successfully');
    e.preventDefault();
    }
     });
});
function number_only_accept(event) {


if (event.keyCode < 48 || event.keyCode > 57) {
    event.preventDefault();
}
}

</script>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\personal\projects\online_course_registration\resources\views/student/print.blade.php ENDPATH**/ ?>
<?php $__env->startSection('title','Online Course Registration - Admin | view session page'); ?>

<!-- header start  -->
<?php echo $__env->make('layouts.admin_header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<!-- header end -->

<!-- main content start -->
<?php $__env->startSection('main-content'); ?>
<div class="home-content">
<div class="container">
    <h3 class="text-primary">Student Registration</h3>
    <p style="border-bottom:4px solid rgb(13,110,253);" class="mt-3 bg-primary">
    <div class="row">
        <div class="col-md-6 offset-3">
            <div class="card">
                <div class="card-header bg-info">Student Registration</div>
                <div class="card-body">
            <form action="<?php echo e(route('admin.reg_student')); ?>" method="POST" autocomplete="off">
              <?php echo csrf_field(); ?>
                <div class="mb-3">
                  <label for="student_name" class="form-label">Student Name:</label>
                  <input type="text" class="form-control" value="<?php echo e(old('student_name')); ?>" id="student_name" placeholder="Enter Student Name" name="student_name">
                  <span class="text-danger"><?php echo e($errors->first('student_name')); ?></span>
                </div>
                <div class="mb-3">
                  <label for="reg_no" class="form-label">Student Registration No:</label>
                  <input type="text" class="form-control" value="<?php echo e(old('reg_no')); ?>" maxlength="15" onkeypress="number_only_accept(event)" id="reg_no" placeholder="Enter Registration No" name="reg_no">
                  <span class="text-danger"><?php echo e($errors->first('reg_no')); ?></span>
                </div>
                <div class="mb-3">
                    <label for="password" class="form-label">Password:</label>
                    <input type="text" readonly class="form-control" value="test@123" id="password" placeholder="Enter Password" name="password">
                    <span class="text-danger"><?php echo e($errors->first('password')); ?></span>
                  </div>
                <button type="submit" class="btn btn-primary"><i class="fa-solid fa-circle-plus"></i> Add Student</button>
              </form>

            </div>
        </div>
        </div>
    </div>

</div>
</div>
<?php $__env->stopSection(); ?>

<script src="https://code.jquery.com/jquery-3.7.1.js"></script>
<script>
     $(document).ready(function(){
    $(document).on('submit', '#manage_course', function(e) {
    var a=confirm("Are you sure you want to Delete :");
    if(a)
    {
        return true;
    }
    else
    {
    alert('Cancelled successfully');
    e.preventDefault();
    }
     });
});
function number_only_accept(event) {


if (event.keyCode < 48 || event.keyCode > 57) {
    event.preventDefault();
}
}

</script>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\personal\projects\online_course_registration\resources\views/admin/add_student.blade.php ENDPATH**/ ?>
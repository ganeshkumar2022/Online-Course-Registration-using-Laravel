<?php $__env->startSection('title','Online Course Registration - Home page'); ?>
<style>
body
{
    height:100vh;
    overflow:hidden;
}
</style>

<!-- header start  -->
<?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<!-- header end -->

<!-- main content start -->
<?php $__env->startSection('main-content'); ?>
<div class="home-content">
<div class="mains-con" style="background-image:url('<?php echo e(asset('assets/images/bg.jpg')); ?>');height:70vh;width:100%;background-size:100% 100%;">

</div>
</div>
<?php $__env->stopSection(); ?>
<!-- main content end -->

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\personal\projects\online_course_registration\resources\views/home.blade.php ENDPATH**/ ?>
<?php $__env->startSection('title','Online Course Registration - Admin | view session page'); ?>

<!-- header start  -->
<?php echo $__env->make('layouts.admin_header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<!-- header end -->

<!-- main content start -->
<?php $__env->startSection('main-content'); ?>
<div class="home-content">
<div class="container">
    <h3 class="text-primary">Edit Course</h3>
    <p style="border-bottom:4px solid rgb(13,110,253);" class="mt-3 bg-primary">
    <div class="row">
        <div class="col-md-6 offset-3">
            <div class="card">
                <div class="card-header bg-info">Course</div>
                <div class="card-body">
            <form action="<?php echo e(route('admin.update_course',$data->id)); ?>" method="POST" autocomplete="off">
              <?php echo csrf_field(); ?>
              <?php echo method_field('PUT'); ?>
              <p><b>Last Updated at :<?php echo e($data->updated_at); ?></b></p>
                <div class="mb-3">
                  <label for="course_code" class="form-label">Course Code:</label>
                  <input type="text" class="form-control" value="<?php echo e($data->course_code); ?>" id="course_code" placeholder="Enter Course Code" name="course_code">
                  <span class="text-danger"><?php echo e($errors->first('course_code')); ?></span>
                </div>
                <div class="mb-3">
                  <label for="course_name" class="form-label">Course Name:</label>
                  <input type="text" class="form-control" value="<?php echo e($data->course_name); ?>" id="course_name" placeholder="Enter Course Name" name="course_name">
                  <span class="text-danger"><?php echo e($errors->first('course_name')); ?></span>
                </div>
                <div class="mb-3">
                  <label for="course_unit" class="form-label">Course unit:</label>
                  <input type="text" class="form-control" value="<?php echo e($data->course_unit); ?>" maxlength="3" onkeypress="number_only_accept(event)" id="course_unit" placeholder="Enter Course unit" name="course_unit">
                  <span class="text-danger"><?php echo e($errors->first('course_unit')); ?></span>
                </div>
                <div class="mb-3">
                  <label for="seat_limit" class="form-label">Seat Limit:</label>
                  <input type="text" class="form-control" value="<?php echo e($data->seat_limit); ?>" maxlength="6" onkeypress="number_only_accept(event)" id="seat_limit" placeholder="Enter Seat Limit" name="seat_limit">
                  <span class="text-danger"><?php echo e($errors->first('seat_limit')); ?></span>
                </div>
                <button type="submit" class="btn btn-primary"><i class="fa-solid fa-calendar-days"></i> Update</button>
              </form>

            </div>
        </div>
        </div>
    </div>
</div>
</div>
</div>
<?php $__env->stopSection(); ?>

<script>

function number_only_accept(event) {


if (event.keyCode < 48 || event.keyCode > 57) {
    event.preventDefault();
}
}

</script>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\personal\projects\online_course_registration\resources\views/admin/edit_course.blade.php ENDPATH**/ ?>
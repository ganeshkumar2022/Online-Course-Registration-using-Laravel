-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Nov 30, 2024 at 02:08 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.0.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `online_course_registration`
--

-- --------------------------------------------------------

--
-- Table structure for table `add_courses`
--

CREATE TABLE `add_courses` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `course_code` varchar(255) NOT NULL,
  `course_name` varchar(255) NOT NULL,
  `course_unit` int(11) NOT NULL,
  `seat_limit` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `add_courses`
--

INSERT INTO `add_courses` (`id`, `course_code`, `course_name`, `course_unit`, `seat_limit`, `created_at`, `updated_at`) VALUES
(2, 'PHP01', 'PHP', 5, 10, '2024-11-23 13:10:49', '2024-11-23 13:10:49'),
(3, 'JAVA24', 'java', 6, 25, '2024-11-23 13:11:21', '2024-11-23 13:11:21'),
(4, 'C++1', 'C++', 5, 26, '2024-11-23 20:09:39', '2024-11-23 20:09:39'),
(6, 'Python201', 'python', 6, 50, '2024-11-23 20:09:54', '2024-11-23 20:28:20');

-- --------------------------------------------------------

--
-- Table structure for table `add_departments`
--

CREATE TABLE `add_departments` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `department_name` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `add_departments`
--

INSERT INTO `add_departments` (`id`, `department_name`, `created_at`, `updated_at`) VALUES
(1, 'Accounts', '2024-11-23 12:43:26', '2024-11-23 12:43:26'),
(2, 'HR', '2024-11-23 12:43:40', '2024-11-23 12:43:40'),
(3, 'IT', '2024-11-23 12:43:46', '2024-11-23 12:43:46'),
(4, 'Maths', '2024-11-23 12:43:51', '2024-11-23 12:43:51');

-- --------------------------------------------------------

--
-- Table structure for table `add_enrolls`
--

CREATE TABLE `add_enrolls` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `student_id` int(11) NOT NULL,
  `student_name` varchar(255) NOT NULL,
  `reg_no` varchar(255) NOT NULL,
  `image_path` varchar(255) NOT NULL,
  `session_id` int(11) NOT NULL,
  `department_id` int(11) NOT NULL,
  `level_id` int(11) NOT NULL,
  `semester_id` int(11) NOT NULL,
  `course_id` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `add_enrolls`
--

INSERT INTO `add_enrolls` (`id`, `student_id`, `student_name`, `reg_no`, `image_path`, `session_id`, `department_id`, `level_id`, `semester_id`, `course_id`, `created_at`, `updated_at`) VALUES
(1, 3, 'samantha', '423234234234242', 'images.jpg', 15, 3, 1, 2, 2, '2024-11-26 23:39:07', '2024-11-26 23:39:07'),
(2, 3, 'samantha', '423234234234242', 'samantha.jpg', 15, 2, 3, 1, 3, '2024-11-26 23:40:23', '2024-11-26 23:40:23'),
(3, 5, 'ganeshr', '423423423423422', '129133849a282661504e10ed8405f135.jpg', 14, 1, 2, 5, 4, '2024-11-29 08:57:59', '2024-11-29 08:57:59');

-- --------------------------------------------------------

--
-- Table structure for table `add_news`
--

CREATE TABLE `add_news` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `news_title` varchar(255) NOT NULL,
  `news_description` text NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `add_news`
--

INSERT INTO `add_news` (`id`, `news_title`, `news_description`, `created_at`, `updated_at`) VALUES
(1, 'new course', 'new course available in java and python', '2024-11-24 19:09:45', '2024-11-24 19:09:45'),
(3, 'php also available', 'php latest is available', '2024-11-24 19:13:42', '2024-11-24 19:13:42');

-- --------------------------------------------------------

--
-- Table structure for table `add_semesters`
--

CREATE TABLE `add_semesters` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `semester_name` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `add_semesters`
--

INSERT INTO `add_semesters` (`id`, `semester_name`, `created_at`, `updated_at`) VALUES
(1, 1, '2024-11-23 00:25:26', '2024-11-23 00:25:26'),
(2, 2, '2024-11-23 00:25:34', '2024-11-23 00:25:34'),
(3, 3, '2024-11-23 00:25:38', '2024-11-23 00:25:38'),
(4, 4, '2024-11-23 00:25:43', '2024-11-23 00:25:43'),
(5, 5, '2024-11-23 00:25:51', '2024-11-23 00:25:51');

-- --------------------------------------------------------

--
-- Table structure for table `add_sessions`
--

CREATE TABLE `add_sessions` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `session_name` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `add_sessions`
--

INSERT INTO `add_sessions` (`id`, `session_name`, `created_at`, `updated_at`) VALUES
(14, 2023, '2024-11-23 00:26:00', '2024-11-23 00:26:00'),
(15, 2024, '2024-11-23 00:26:05', '2024-11-23 00:26:05'),
(16, 2022, '2024-11-23 00:26:11', '2024-11-23 00:26:11'),
(17, 2021, '2024-11-23 00:26:22', '2024-11-23 00:26:22');

-- --------------------------------------------------------

--
-- Table structure for table `admins`
--

CREATE TABLE `admins` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `admins`
--

INSERT INTO `admins` (`id`, `email`, `password`, `created_at`, `updated_at`) VALUES
(1, 'admin@gmail.com', '$2y$10$fjz6VqZHMqInEK2qUOQpQuIb.Zr5aA/6OqdSy3KliHrWHx6JePXQi', NULL, '2024-11-21 09:04:57');

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(255) NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(1, '2019_12_14_000001_create_personal_access_tokens_table', 1),
(2, '2024_11_19_011441_create_admins_table', 1),
(4, '2024_11_21_155716_create_add_sessions_table', 2),
(5, '2024_11_22_011753_create_add_semesters_table', 3),
(6, '2024_11_22_163228_create_add_departments_table', 4),
(7, '2024_11_23_044544_create_add_courses_table', 5),
(8, '2024_11_23_123049_create_students_table', 6),
(9, '2024_11_24_104702_create_add_news_table', 7),
(10, '2024_11_26_010328_create_add_enrolls_table', 8),
(12, '2024_11_29_011019_add_profile_image_in_student', 9),
(13, '2024_11_30_003412_create_studentlogs_table', 10);

-- --------------------------------------------------------

--
-- Table structure for table `personal_access_tokens`
--

CREATE TABLE `personal_access_tokens` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `tokenable_type` varchar(255) NOT NULL,
  `tokenable_id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) NOT NULL,
  `token` varchar(64) NOT NULL,
  `abilities` text DEFAULT NULL,
  `last_used_at` timestamp NULL DEFAULT NULL,
  `expires_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `studentlogs`
--

CREATE TABLE `studentlogs` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `regno` varchar(255) NOT NULL,
  `ip_address` varchar(255) DEFAULT NULL,
  `login_time` varchar(255) DEFAULT NULL,
  `logout_time` varchar(255) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `studentlogs`
--

INSERT INTO `studentlogs` (`id`, `regno`, `ip_address`, `login_time`, `logout_time`, `created_at`, `updated_at`) VALUES
(2, '424234234234234', '127.0.0.1', '30-11-2024 12:51:40am', '30-11-2024 06:27:37am', '2024-11-30 08:51:40', '2024-11-30 14:27:37'),
(3, '123456789', '127.0.0.1', '30-11-2024 06:29:08am', '', '2024-11-30 14:29:08', '2024-11-30 14:29:11');

-- --------------------------------------------------------

--
-- Table structure for table `students`
--

CREATE TABLE `students` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `student_name` varchar(255) NOT NULL,
  `reg_no` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `image_path` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `students`
--

INSERT INTO `students` (`id`, `student_name`, `reg_no`, `password`, `created_at`, `updated_at`, `image_path`) VALUES
(2, 'nishitha', '41233123123223', '$2y$10$qG108hseWVYHPFU6GAehh.e8P2SKxwnWBcQThuxvxBSTNer.iZbOy', '2024-11-23 20:53:57', '2024-11-23 20:53:57', NULL),
(3, 'samantha', '423234234234242', '$2y$10$V/lDc5hsyFPE4IYb1fvBR.BGzo2eKStXxCYp/AWclXpLjB7fRVdOm', '2024-11-23 20:57:30', '2024-11-23 20:57:30', NULL),
(5, 'ganesh', '423423423423422', '$2y$10$/UmoMWYR6pqW7pPczNvqmOloO3/ZTlHYvFYVrhxu.aTfNaFWexKvS', '2024-11-24 10:36:29', '2024-11-29 09:34:55', 'download.jpg'),
(6, 'wasd', '453454545345345', '$2y$10$JIe8wHwyBvecqSs8KDOe3O/S6DkBVUC3n6228qhUoVwqoBerscz3W', '2024-11-24 10:36:46', '2024-11-24 10:36:46', NULL),
(7, 'sri', '424234234234234', '$2y$10$tiYexbXWKsozDKax5LcAX.ti4w0cW81ypDvIRU8N3wdI71QDLPJBK', '2024-11-24 10:36:59', '2024-11-24 10:36:59', NULL),
(8, 'kajal agarwal', '123456789', '$2y$10$kuCksAPQU7snJuNOgHcGCOikjVakQaZ/7YgIPpAd.ryEuidN/Wwmq', '2024-11-30 08:43:57', '2024-11-30 08:43:57', NULL);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `add_courses`
--
ALTER TABLE `add_courses`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `add_courses_course_name_unique` (`course_name`);

--
-- Indexes for table `add_departments`
--
ALTER TABLE `add_departments`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `add_departments_department_name_unique` (`department_name`);

--
-- Indexes for table `add_enrolls`
--
ALTER TABLE `add_enrolls`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `add_news`
--
ALTER TABLE `add_news`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `add_semesters`
--
ALTER TABLE `add_semesters`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `add_semesters_semester_name_unique` (`semester_name`);

--
-- Indexes for table `add_sessions`
--
ALTER TABLE `add_sessions`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `add_sessions_session_name_unique` (`session_name`);

--
-- Indexes for table `admins`
--
ALTER TABLE `admins`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `admins_email_unique` (`email`);

--
-- Indexes for table `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `personal_access_tokens`
--
ALTER TABLE `personal_access_tokens`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `personal_access_tokens_token_unique` (`token`),
  ADD KEY `personal_access_tokens_tokenable_type_tokenable_id_index` (`tokenable_type`,`tokenable_id`);

--
-- Indexes for table `studentlogs`
--
ALTER TABLE `studentlogs`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `students`
--
ALTER TABLE `students`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `students_reg_no_unique` (`reg_no`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `add_courses`
--
ALTER TABLE `add_courses`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `add_departments`
--
ALTER TABLE `add_departments`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `add_enrolls`
--
ALTER TABLE `add_enrolls`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `add_news`
--
ALTER TABLE `add_news`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `add_semesters`
--
ALTER TABLE `add_semesters`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `add_sessions`
--
ALTER TABLE `add_sessions`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- AUTO_INCREMENT for table `admins`
--
ALTER TABLE `admins`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT for table `personal_access_tokens`
--
ALTER TABLE `personal_access_tokens`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `studentlogs`
--
ALTER TABLE `studentlogs`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `students`
--
ALTER TABLE `students`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;

<?php

use App\Http\Controllers\AdminController;
use App\Http\Controllers\MainPageController;
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\StudentController;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get("/",[MainPageController::class,"index"])->name('home');
Route::get("/student_login",[MainPageController::class,"student_login"])->name('student_login');
Route::get("/admin_login",[MainPageController::class,"admin_login"])->name('admin_login');
Route::post("/verify_admin_login",[MainPageController::class,"verify_admin_login"])->name('verify_admin_login');
Route::post("/verify_student_login",[MainPageController::class,"verify_student_login"])->name('verify_student_login');


Route::middleware(['AdminAuthenticationCheck'])->group(function(){

    Route::get("/admin/dashboard",[AdminController::class,"dashboard"])->name('admin.dashboard');
    Route::get("/admin/logout",[AdminController::class,"logout"])->name('admin.logout');
    Route::put("/admin/update_password",[AdminController::class,"update_password"])->name('admin.update_password');

    //session start
    Route::get("/admin/view_session",[AdminController::class,"view_session"])->name('admin.view_session');
    Route::post("/admin/add_session",[AdminController::class,"add_session"])->name('admin.add_session');
    Route::delete("/admin/delete_session/{id}",[AdminController::class,"delete_session"])->name('admin.delete_session');
    //session end

    //semester start
    Route::get("/admin/view_semester",[AdminController::class,"view_semester"])->name('admin.view_semester');
    Route::post("/admin/add_semester",[AdminController::class,"add_semester"])->name('admin.add_semester');
    Route::delete("/admin/delete_semester/{id}",[AdminController::class,"delete_semester"])->name('admin.delete_semester');
    //semester end

    //department start
    Route::get("/admin/view_department",[AdminController::class,"view_department"])->name('admin.view_department');
    Route::post("/admin/add_department",[AdminController::class,"add_department"])->name('admin.add_department');
    Route::delete("/admin/delete_department/{id}",[AdminController::class,"delete_department"])->name('admin.delete_department');
    //department end

      //course start
      Route::get("/admin/view_course",[AdminController::class,"view_course"])->name('admin.view_course');
      Route::put('/admin/update_course/{id}',[AdminController::class,"update_course"])->name('admin.update_course');
      Route::post("/admin/add_course",[AdminController::class,"add_course"])->name('admin.add_course');
      Route::get("/admin/edit_course/{id}",[AdminController::class,"edit_course"])->name('admin.edit_course');
      Route::delete("/admin/delete_course/{id}",[AdminController::class,"delete_course"])->name('admin.delete_course');
      //course end

      //student start
      Route::get("/admin/add_student",[AdminController::class,"add_student"])->name('admin.add_student');
      Route::post("/admin/register_student",[AdminController::class,"register_student"])->name('admin.reg_student');
      Route::get("/admin/manage_student",[AdminController::class,"manage_student"])->name('admin.manage_student');
      Route::delete("/admin/delete_student/{id}",[AdminController::class,"delete_student"])->name('admin.delete_student');
      Route::get("/admin/edit_student/{id}",[AdminController::class,"edit_student"])->name('admin.edit_student');
      Route::put("/admin/update_student/{id}",[AdminController::class,"update_student"])->name('admin.update_student');
      Route::get("/admin/enroll_history",[AdminController::class,"enroll_history"])->name('admin.enroll_history');
      Route::get("/admin/student_log",[AdminController::class,"student_log"])->name('admin.student_log');
      Route::get("/admin/print_data/{aid}/{sid}",[AdminController::class,"print_fun"])->name('admin.print_fun');
      //student end

      //add news start
      Route::get("/admin/add_news",[AdminController::class,"add_news"])->name('admin.add_news');
      Route::post("/admin/register_news",[AdminController::class,"register_news"])->name('admin.register_news');
      Route::delete("/admin/delete_news/{id}",[AdminController::class,"delete_news"])->name('admin.delete_news');
      //add news end

});


Route::middleware(['StudentAuthenticateCheck'])->group(function(){

    //student start
    Route::get("/student/add_enroll",[StudentController::class,"add_enroll"])->name('student.add_enroll');
    Route::post("/student/reg_enroll",[StudentController::class,"register_enroll"])->name('student.reg_enroll');
    Route::get("/student/logout",[StudentController::class,"logout"])->name('student.logout');
    Route::get("/student/view_enroll",[StudentController::class,"view_enroll"])->name('student.view_enroll');
    Route::get("/student/print_page/{id}",[StudentController::class,"print_fun"])->name('student.print_fun');
    Route::get("/student/change_password",[StudentController::class,"change_password"])->name('student.change_password');
    Route::put("/student/update_password",[StudentController::class,"update_password"])->name('student.update_password');
    Route::get("/student/profile_change",[StudentController::class,"profile_change"])->name('student.profile_change');
    Route::post("/student/update_profile",[StudentController::class,"update_profile"])->name('student.update_profile');
    //student end
});

@extends('layouts.master')
@section('title','Online Course Registration - Admin | view session page')

<!-- header start  -->
@include('layouts.admin_header')
<!-- header end -->

<!-- main content start -->
@section('main-content')
<div class="home-content">
<div class="container">
    <h3 class="text-primary">Manage Student</h3>
    <p style="border-bottom:4px solid rgb(13,110,253);" class="mt-3 bg-primary">
    <div class="row">

    <div class="col-md-12 mt-4">
        <div class="card">
        <div class="card-header">Manage Student</div>
        <div class="card-body">
            <table class="table table-bordered">
                <tr class="table-primary">
                    <th>S.No</th>
                    <th>Reg no</th>
                    <th>Student Name</th>
                    <th>Creation Date</th>
                    <th>Action</th>
                </tr>
                @foreach ($data as $sno=>$row)
                <tr>
                    <td>{{ $sno+1 }}</td>
                    <td>{{ $row->reg_no }}</td>
                    <td>{{ $row->student_name }}</td>
                    <td>{{ $row->created_at }}</td>
                    <td>
                        <div class="row">
                            <div class="col float-end">
                                <a href="{{ route('admin.edit_student',$row->id) }}" class="btn btn-success btn-sm"><i class="fa-solid fa-calendar-days"></i> Edit</a>
                            </div>
                            <div class="col float-start">

                                <form method="post" id="manage_student" action="{{ route('admin.delete_student',$row->id) }}">
                                    @csrf
                                    @method('DELETE')
                                    <button type="submit" name="delete" class="btn del_btn btn-danger btn-sm"><i class="fa-solid fa-trash"></i> Delete</button>
                                </form>
                            </div>
                        </div>
                    </td>
                </tr>
                @endforeach
                @if (count($data)==0)
                <tr>
                    <td colspan="7">No records found</td>
                </tr>
                @endif
            </table>
        </div>
    </div>
</div>
</div>
</div>
@endsection

<script src="https://code.jquery.com/jquery-3.7.1.js"></script>
<script>
     $(document).ready(function(){
    $(document).on('submit', '#manage_student', function(e) {
    var a=confirm("Are you sure you want to Delete :");
    if(a)
    {
        return true;
    }
    else
    {
    alert('Cancelled successfully');
    e.preventDefault();
    }
     });
});
function number_only_accept(event) {


if (event.keyCode < 48 || event.keyCode > 57) {
    event.preventDefault();
}
}

</script>

@extends('layouts.master')
@section('title','Online Course Registration - Admin | view session page')

<!-- header start  -->
@include('layouts.admin_header')
<!-- header end -->

<!-- main content start -->
@section('main-content')
<div class="home-content">
<div class="container">
    <h3 class="text-primary">Edit Course</h3>
    <p style="border-bottom:4px solid rgb(13,110,253);" class="mt-3 bg-primary">
    <div class="row">
        <div class="col-md-6 offset-3">
            <div class="card">
                <div class="card-header bg-info">Course</div>
                <div class="card-body">
            <form action="{{ route('admin.update_course',$data->id) }}" method="POST" autocomplete="off">
              @csrf
              @method('PUT')
              <p><b>Last Updated at :{{ $data->updated_at }}</b></p>
                <div class="mb-3">
                  <label for="course_code" class="form-label">Course Code:</label>
                  <input type="text" class="form-control" value="{{ $data->course_code }}" id="course_code" placeholder="Enter Course Code" name="course_code">
                  <span class="text-danger">{{ $errors->first('course_code') }}</span>
                </div>
                <div class="mb-3">
                  <label for="course_name" class="form-label">Course Name:</label>
                  <input type="text" class="form-control" value="{{ $data->course_name }}" id="course_name" placeholder="Enter Course Name" name="course_name">
                  <span class="text-danger">{{ $errors->first('course_name') }}</span>
                </div>
                <div class="mb-3">
                  <label for="course_unit" class="form-label">Course unit:</label>
                  <input type="text" class="form-control" value="{{ $data->course_unit }}" maxlength="3" onkeypress="number_only_accept(event)" id="course_unit" placeholder="Enter Course unit" name="course_unit">
                  <span class="text-danger">{{ $errors->first('course_unit') }}</span>
                </div>
                <div class="mb-3">
                  <label for="seat_limit" class="form-label">Seat Limit:</label>
                  <input type="text" class="form-control" value="{{ $data->seat_limit }}" maxlength="6" onkeypress="number_only_accept(event)" id="seat_limit" placeholder="Enter Seat Limit" name="seat_limit">
                  <span class="text-danger">{{ $errors->first('seat_limit') }}</span>
                </div>
                <button type="submit" class="btn btn-primary"><i class="fa-solid fa-calendar-days"></i> Update</button>
              </form>

            </div>
        </div>
        </div>
    </div>
</div>
</div>
</div>
@endsection

<script>

function number_only_accept(event) {


if (event.keyCode < 48 || event.keyCode > 57) {
    event.preventDefault();
}
}

</script>

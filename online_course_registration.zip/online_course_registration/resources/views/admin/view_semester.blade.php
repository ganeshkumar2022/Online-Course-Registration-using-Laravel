@extends('layouts.master')
@section('title','Online Course Registration - Admin | view session page')

<!-- header start  -->
@include('layouts.admin_header')
<!-- header end -->

<!-- main content start -->
@section('main-content')
<div class="home-content">
<div class="container">
    <h3 class="text-primary">Add Semester</h3>
    <p style="border-bottom:4px solid rgb(13,110,253);" class="mt-3 bg-primary">
    <div class="row">
        <div class="col-md-6 offset-3">
            <div class="card">
                <div class="card-header bg-info">Semester</div>
                <div class="card-body">
            <form action="{{ route('admin.add_semester') }}" method="POST" autocomplete="off">
              @csrf
                <div class="mb-3">
                  <label for="semester_name" class="form-label">Semester:</label>
                  <input type="text" maxlength="4" onkeypress="number_only_accept(event)" class="form-control" value="{{ old('semester_name') }}" id="semester_name" placeholder="Enter Semester" name="semester_name">
                  <span class="text-danger">{{ $errors->first('semester_name') }}</span>
                </div>
                <button type="submit" class="btn btn-primary"><i class="fa-solid fa-circle-plus"></i> Create</button>
              </form>

            </div>
        </div>
        </div>
    </div>
    <div class="col-md-12 mt-4">
        <div class="card">
        <div class="card-header">Manage Semester</div>
        <div class="card-body">
            <table class="table table-bordered">
                <tr class="table-primary">
                    <th>S.No</th>
                    <th>Semester Name</th>
                    <th>Creation Date</th>
                    <th>Action</th>
                </tr>
                @foreach ($data as $sno=>$row)
                <tr>
                    <td>{{ $sno+1 }}</td>
                    <td>{{ $row->semester_name }}</td>
                    <td>{{ $row->created_at }}</td>
                    <td>
                        <form method="post" id="manage_semester" action="{{ route('admin.delete_semester',$row->id) }}">
                            @csrf
                            @method('DELETE')
                            <button type="submit" name="delete" class="btn del_btn btn-danger btn-sm"><i class="fa-solid fa-trash"></i> Delete</button>
                        </form>
                    </td>
                </tr>
                @endforeach
                @if (count($data)==0)
                <tr>
                    <td colspan="4">No records found</td>
                </tr>
                @endif
            </table>
        </div>
    </div>
</div>
</div>
</div>
@endsection

<script src="https://code.jquery.com/jquery-3.7.1.js"></script>
<script>
     $(document).ready(function(){
    $(document).on('submit', '#manage_semester', function(e) {
    var a=confirm("Are you sure you want to Delete :");
    if(a)
    {
        return true;
    }
    else
    {
    alert('Cancelled successfully');
    e.preventDefault();
    }
     });
});


    function number_only_accept(event) {


        if (event.keyCode < 48 || event.keyCode > 57) {
            event.preventDefault();
        }
    }
</script>


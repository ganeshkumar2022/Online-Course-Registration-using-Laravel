@extends('layouts.master')
@section('title','Online Course Registration - Admin | Dashboard page')

<!-- header start  -->
@include('layouts.admin_header')
<!-- header end -->

<!-- main content start -->
@section('main-content')
<div class="home-content">
<div class="container">
    <h3 class="text-primary">Admin Change Password</h3>
    <p style="border-bottom:4px solid rgb(13,110,253);" class="mt-3 bg-primary">
    <div class="row">
        <div class="col-md-6 offset-3">
            <div class="card">
                <div class="card-header bg-info">Change Password</div>
                <div class="card-body">
            <form action="{{ route('admin.update_password') }}" method="POST" autocomplete="off">
              @csrf
              @method('PUT')
                <div class="mb-3">
                  <label for="current_password" class="form-label">Current Password:</label>
                  <input type="password" class="form-control" value="{{ old('current_password') }}" id="current_password" placeholder="Enter Current password" name="current_password">
                  <span class="text-danger">{{ $errors->first('current_password') }}</span>
                </div>
                <div class="mb-3">
                    <label for="new_password" class="form-label">New Password:</label>
                    <input type="password" class="form-control" value="{{ old('new_password') }}" id="new_password" placeholder="Enter New password" name="new_password">
                    <span class="text-danger">{{ $errors->first('new_password') }}</span>
                  </div>
                  <div class="mb-3">
                    <label for="confirm_password" class="form-label">Confirm Password:</label>
                    <input type="password" class="form-control" value="{{ old('confirm_password') }}" id="confirm_password" placeholder="Enter Confirm password" name="confirm_password">
                    <span class="text-danger">{{ $errors->first('confirm_password') }}</span>
                  </div>
                <button type="submit" class="btn btn-primary"><i class="fa-solid fa-user"></i> Update</button>
              </form>

            </div>
        </div>
        </div>
    </div>
</div>
</div>
@endsection
<!-- main content end -->



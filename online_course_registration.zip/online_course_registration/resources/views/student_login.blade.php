@extends('layouts.master')
@section('title','Online Course Registration - Home page')

<!-- header start  -->
@include('layouts.header')
<!-- header end -->

<!-- main content start -->
@section('main-content')
<div class="home-content">
<div class="container">
    <div class="row">
        <div class="col-md-6">
            <form action="{{ route('verify_student_login') }}" method="POST" autocomplete="off">
              @csrf
                <h3 class="text-primary">Student Login</h3>
                <p style="border-bottom:4px solid rgb(13,110,253);" class="mt-3 bg-primary">
                <div class="mb-3 mt-3">
                  <label for="reg_no" class="form-label">Enter Reg no:</label>
                  <input type="text" class="form-control" value="{{ old('reg_no') }}" id="reg_no" placeholder="Enter Reg no" name="reg_no">
                  <span class="text-danger">{{ $errors->first('reg_no') }}</span>
                </div>
                <div class="mb-3">
                  <label for="password" class="form-label">Enter Password:</label>
                  <input type="password" class="form-control" value="{{ old('password') }}" id="password" placeholder="Enter password" name="password">
                  <span class="text-danger">{{ $errors->first('password') }}</span>
                </div>
                <button type="submit" class="btn btn-primary"><i class="fa-solid fa-user"></i> Login</button>
              </form>
        </div>
        <div class="col-md-6">
           <div class="alert alert-success mt-3">
            <h3>Latest News / Update</h3>
            <marquee direction="up">
            <ul>
                @foreach ($data as $row)
                <li><b>{{ $row->news_title }}:</b> {{ $row->news_description }}</li>
                @endforeach
            </ul>
        </marquee>
           </div>
        </div>
    </div>
</div>
</div>
@endsection
<!-- main content end -->



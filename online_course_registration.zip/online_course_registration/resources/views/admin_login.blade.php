@extends('layouts.master')
@section('title','Online Course Registration - Home page')

<!-- header start  -->
@include('layouts.header')
<!-- header end -->

<!-- main content start -->
@section('main-content')
<div class="home-content">
<div class="container">
    <div class="row">
        <div class="col-md-6">
            <form action="{{ route('verify_admin_login') }}" method="POST" autocomplete="off">
              @csrf
                <h3 class="text-primary">Admin Login</h3>
                <p style="border-bottom:4px solid rgb(13,110,253);" class="mt-3 bg-primary">
                <div class="mb-3 mt-3">
                  <label for="email" class="form-label">Enter Email:</label>
                  <input type="text" class="form-control" value="{{ old('email') }}" id="email" placeholder="Enter email" name="email">
                  <span class="text-danger">{{ $errors->first('email') }}</span>
                </div>
                <div class="mb-3">
                  <label for="password" class="form-label">Enter Password:</label>
                  <input type="password" class="form-control" value="{{ old('password') }}" id="password" placeholder="Enter password" name="password">
                  <span class="text-danger">{{ $errors->first('password') }}</span>
                </div>
                <button type="submit" class="btn btn-primary"><i class="fa-solid fa-user"></i> Login</button>
              </form>
        </div>
        <div class="col-md-6">
            <img src="{{ asset('assets/images/admin.jpg') }}" class="img-fluid">
        </div>
    </div>
</div>
</div>
@endsection
<!-- main content end -->



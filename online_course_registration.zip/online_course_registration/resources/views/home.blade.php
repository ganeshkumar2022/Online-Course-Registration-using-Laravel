@extends('layouts.master')
@section('title','Online Course Registration - Home page')
<style>
body
{
    height:100vh;
    overflow:hidden;
}
</style>

<!-- header start  -->
@include('layouts.header')
<!-- header end -->

<!-- main content start -->
@section('main-content')
<div class="home-content">
<div class="mains-con" style="background-image:url('{{ asset('assets/images/bg.jpg') }}');height:70vh;width:100%;background-size:100% 100%;">

</div>
</div>
@endsection
<!-- main content end -->

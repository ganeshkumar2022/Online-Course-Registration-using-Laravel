@extends('layouts.master')
@section('title','Online Course Registration - Student | Add enroll page')

<!-- header start  -->
@include('layouts.student_header')
<!-- header end -->

<!-- main content start -->
@section('main-content')
<div class="home-content">
<div class="container">
    <h3 class="text-primary">Course Enroll</h3>
    <p style="border-bottom:4px solid rgb(13,110,253);" class="mt-3 bg-primary">
    <div class="row">
        <div class="col-md-6 offset-3">
            <div class="card">
                <div class="card-header bg-info">Course Enroll</div>
                <div class="card-body">
            <form action="{{ route('student.reg_enroll') }}" method="POST" enctype="multipart/form-data" autocomplete="off">
              @csrf
                <div class="mb-3">
                  <label for="student_name" class="form-label">Student Name:</label>
                  <input type="text" class="form-control" value="{{ $student_data->student_name }}" id="student_name" placeholder="Enter Student Name" name="student_name">
                  <span class="text-danger">{{ $errors->first('student_name') }}</span>
                </div>
                <div class="mb-3">
                  <label for="reg_no" class="form-label">Student Registration No:</label>
                  <input type="text" readonly class="form-control" value="{{ $student_data->reg_no }}" maxlength="15" onkeypress="number_only_accept(event)" id="reg_no" placeholder="Enter Registration No" name="reg_no">
                  <span class="text-danger">{{ $errors->first('reg_no') }}</span>
                </div>
                <div class="mb-3">
                    <label for="myimage" class="form-label">Student Photo:</label>
                    <input type="file" name="myimage" id="myimage" class="form-control">
                    <span class="text-danger">{{ $errors->first('myimage') }}</span>
                  </div>

                <div class="mb-3">
                    <label for="session_data" class="form-label">Session:</label>
                    <select class="form-select" name="session_data">
                        <option value="">Choose session</option>
                        @foreach ($session_data as $sess)
                        <option value="{{ $sess->id }}" @if(old('session_data')==$sess->id) selected @endif >{{ $sess->session_name }}</option>
                        @endforeach
                    </select>
                    <span class="text-danger">{{ $errors->first('session_data') }}</span>
                  </div>

                <div class="mb-3">
                    <label for="department" class="form-label">Department:</label>
                    <select class="form-select" name="department" id="department">
                        <option value="">Choose Department</option>
                        @foreach ($department as $depart)
                        <option value="{{ $depart->id }}" @if(old('department')==$depart->id) selected @endif>{{ $depart->department_name }}</option>
                        @endforeach
                      </select>
                    <span class="text-danger">{{ $errors->first('department') }}</span>
                </div>

                <div class="mb-3">
                    <label for="level" class="form-label">Level:</label>
                    <select class="form-select" name="level" id="level">
                      <option value="">Choose Level</option>
                      <option value="1"  @if(old('level')==1) selected @endif>1</option>
                      <option value="2"  @if(old('level')==2) selected @endif>2</option>
                      <option value="3" @if(old('level')==3) selected @endif>3</option>
                    </select>
                    <span class="text-danger">{{ $errors->first('level') }}</span>
                  </div>
                <div class="mb-3">
                    <label for="semester" class="form-label">Semester:</label>
                    <select class="form-select" name="semester" id="semester">
                        <option value="">Choose Semester</option>
                        @foreach ($semester as $sem)
                        <option value="{{ $sem->id }}" @if(old('semester')==$sem->id) selected @endif>{{ $sem->semester_name }}</option>
                        @endforeach
                      </select>
                    <span class="text-danger">{{ $errors->first('semester') }}</span>
                  </div>
                <div class="mb-3">
                    <label for="course" class="form-label">Course:</label>
                    <select class="form-select" name="course" id="course">
                        <option value="">Choose Course</option>
                        @foreach ($course as $cour)
                        <option value="{{ $cour->id }}" @if(old('course')==$cour->id) selected @endif>{{ $cour->course_name }}</option>
                        @endforeach
                      </select>
                    <span class="text-danger">{{ $errors->first('course') }}</span>
                  </div>
                <button type="submit" class="btn btn-primary"><i class="fa-solid fa-circle-plus"></i> Enroll</button>
              </form>

            </div>
        </div>
        </div>
    </div>

</div>
</div>
@endsection

<script src="https://code.jquery.com/jquery-3.7.1.js"></script>
<script>
     $(document).ready(function(){
    $(document).on('submit', '#manage_course', function(e) {
    var a=confirm("Are you sure you want to Delete :");
    if(a)
    {
        return true;
    }
    else
    {
    alert('Cancelled successfully');
    e.preventDefault();
    }
     });
});
function number_only_accept(event) {


if (event.keyCode < 48 || event.keyCode > 57) {
    event.preventDefault();
}
}

</script>

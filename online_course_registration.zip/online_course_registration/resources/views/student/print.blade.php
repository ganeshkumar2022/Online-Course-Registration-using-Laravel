@extends('layouts.master')
@section('title','Online Course Registration - Student | View Enroll page')



<!-- main content start -->
@section('main-content')
<div class="home-content">
<div class="container">

    <div class="row">
        <div class="col-md-12">
            @foreach ($data as $row)
            <div class="card">
                <div class="card-body">
                    <div class="row">
                        <div class="col-md-6">
                            <img src="{{ asset('enroll_images/'.$row->image_path) }}" style="height:200px;width:200px;">
                        </div>
                        <div class="col-md-6">
                            <ul class="list-unstyled float-end text-end mt-4">
                                <li><b>Regno :</b> {{ $student->reg_no }}</li>
                                <li><b>Student Name :</b> {{ $student->student_name }}</li>
                                <li><b>Student Reg Date :</b> {{ $student->created_at }}</li>
                                <li><b>Student Course Enroll Date :</b> {{ $row->created_at }}</li>
                            </ul>
                        </div>
                        <div class="col-md-12">
                            <table class="table mt-3">
                                <tr class="table-secondary">
                                    <th colspan="2">Course Details</th>
                                </tr>
                                <tr>
                                    <td>Course Code</td>
                                    <td><span class="float-end">{{ $row->course_code }}</span></td>
                                </tr>
                                <tr>
                                    <td>Course Name</td>
                                    <td><span class="float-end">{{ $row->course_name }}</span></td>
                                </tr>
                                <tr>
                                    <td>Course Unit</td>
                                    <td><span class="float-end">{{ $row->course_unit }}</span></td>
                                </tr>
                            </table>

                            <table class="table mt-3">
                                <tr class="table-secondary">
                                    <th colspan="2">Other Details</th>
                                </tr>
                                <tr>
                                    <td>Session</td>
                                    <td><span class="float-end">{{ $row->session_name }}</span></td>
                                </tr>
                                <tr>
                                    <td>Department Name</td>
                                    <td><span class="float-end">{{ $row->department_name }}</span></td>
                                </tr>
                                <tr>
                                    <td>Level</td>
                                    <td><span class="float-end">{{ $row->level_id }}</span></td>
                                </tr>
                                <tr>
                                    <td>CGPA</td>
                                    <td><span class="float-end"></span></td>
                                </tr>
                                <tr>
                                    <td>Semester</td>
                                    <td><span class="float-end">{{ $row->semester_name }}</span></td>
                                </tr>
                            </table>
                        </div>
                    </div>
                </div>
            </div>

            @endforeach
        </div>
    </div>

</div>
</div>
@endsection

<script src="https://code.jquery.com/jquery-3.7.1.js"></script>
<script>
     $(document).ready(function(){
    $(document).on('submit', '#manage_course', function(e) {
    var a=confirm("Are you sure you want to Delete :");
    if(a)
    {
        return true;
    }
    else
    {
    alert('Cancelled successfully');
    e.preventDefault();
    }
     });
});
function number_only_accept(event) {


if (event.keyCode < 48 || event.keyCode > 57) {
    event.preventDefault();
}
}

</script>

@extends('layouts.master')
@section('title','Online Course Registration - Student | View Enroll page')

<!-- header start  -->
@include('layouts.student_header')
<!-- header end -->

<!-- main content start -->
@section('main-content')
<div class="home-content">
<div class="container">
    <h3 class="text-primary">Enroll History</h3>
    <p style="border-bottom:4px solid rgb(13,110,253);" class="mt-3 bg-primary">
    <div class="row">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header bg-info">Enroll History</div>
                <div class="card-body">
                <table class="table table-bordered">
                    <tr class="table-primary">
                        <th>S.No</th>
                        <th>Course Name</th>
                        <th>Session</th>
                        <th>Department</th>
                        <th>Level</th>
                        <th>Semester</th>
                        <th>Enrollment Date</th>
                        <th>Action</th>
                    </tr>
                    @foreach ($data as $sno=>$row)
                    <tr>
                        <td>{{ $sno+1 }}</td>
                        <td>{{ $row->course_name }}</td>
                        <td>{{ $row->session_name }}</td>
                        <td>{{ $row->department_name }}</td>
                        <td>{{ $row->level_id }}</td>
                        <td>{{ $row->semester_name }}</td>
                        <td>{{ $row->created_at }}</td>
                        <td>
                            <a href="{{ route('student.print_fun',$row->id) }}" class="btn btn-success"><i class="fa-solid fa-print"></i> Print</a>
                        </td>
                    </tr>
                    @endforeach
                    @if (count($data)==0)
                    <tr>
                        <td colspan="7">No records found</td>
                    </tr>
                    @endif
                </table>

            </div>
        </div>
        </div>
    </div>

</div>
</div>
@endsection

<script src="https://code.jquery.com/jquery-3.7.1.js"></script>
<script>
     $(document).ready(function(){
    $(document).on('submit', '#manage_course', function(e) {
    var a=confirm("Are you sure you want to Delete :");
    if(a)
    {
        return true;
    }
    else
    {
    alert('Cancelled successfully');
    e.preventDefault();
    }
     });
});
function number_only_accept(event) {


if (event.keyCode < 48 || event.keyCode > 57) {
    event.preventDefault();
}
}

</script>

<?php

namespace App\Http\Controllers;

use App\Models\Add_news;
use App\Models\Admin;
use App\Models\Student;
use App\Models\Studentlog;
use Exception;
use Illuminate\Http\Request;

class MainPageController extends Controller
{
    public function index()
    {
        return view('home');
    }

    //admin login start
    public function admin_login()
    {
        return view('admin_login');
    }
    public function verify_admin_login(Request $request)
    {
        $request->validate([
            'email'=>'required|email',
            'password'=>'required'
        ],[
            'email.email'=>'Please enter valid email',
            'email.required'=>'Email field is required',
            'password.required'=>'Password field is required'
        ]);

        $email=strip_tags($request->input('email'));
        $password=strip_tags($request->input('password'));

           $admin=Admin::where("email",$email)->first();
           if($admin)
           {
              if(password_verify($password,$admin->password))
              {
                session(['aid'=>$admin->id]);
                return redirect()->route('admin.dashboard');
              }
              else
              {
                return back()->with('message','Invalid email or password');
              }
           }
           else
           {
            return back()->with('message','Invalid email or password');
           }
     }
    //admin login end

    //student login start
    public function student_login()
    {
        $data=Add_news::orderBy('id','desc')->get();
        return view('student_login',compact('data'));
    }
    public function getUserIP() {
        if (!empty($_SERVER['HTTP_CLIENT_IP'])) {
            // Check if the IP is coming from a shared internet
            return $_SERVER['HTTP_CLIENT_IP'];
        } elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {
            // Check if the IP is forwarded by a proxy server
            return $_SERVER['HTTP_X_FORWARDED_FOR'];
        } else {
            // Default to the remote address
            return $_SERVER['REMOTE_ADDR'];
        }
    }
    public function verify_student_login(Request $request)
    {
        $request->validate([
            'reg_no'=>'required',
            'password'=>'required'
        ],[
            'reg_no.required'=>'Reg no field is required',
            'password.required'=>'Password field is required'
        ]);

        $reg_no=trim(strip_tags($request->input('reg_no')));
        $password=trim(strip_tags($request->input('password')));

           $student=Student::where("reg_no",$reg_no)->first();
           if($student)
           {
              if(password_verify($password,$student->password))
              {
                $logs=new Studentlog();
                $logs->regno=$reg_no;
                $logs->ip_address=$this->getUserIP();
                $logs->login_time=date("d-m-Y h:i:sa");
                $logs->save();
                session(['sid'=>$student->id,"log_id"=>$logs->id]);
                //return redirect()->route('admin.dashboard');
                //return back()->with('message','Login successfully');
                return redirect()->route('student.add_enroll');
              }
              else
              {
                return back()->with('message','Invalid Reg no or password');
              }
           }
           else
           {
            return back()->with('message','Invalid Reg no or password');
           }
   }
    //student login end
}

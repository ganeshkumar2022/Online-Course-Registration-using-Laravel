<?php

namespace App\Http\Controllers;

use App\Models\Add_course;
use App\Models\Student;
use App\Models\Add_department;
use App\Models\Add_news;
use App\Models\Add_semester;
use App\Models\Add_session;
use App\Models\Admin;
use App\Models\Studentlog;
use Exception;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Session;

class AdminController extends Controller
{
    public function dashboard()
    {
        return view('admin.dashboard');
    }
    public function update_password(Request $request)
    {
        $request->validate([
            'current_password'=>'required',
            'new_password'=>['required','string','min:8','regex:/^[a-zA-Z\d]{8,}$/'],
            'confirm_password'=>'required'
        ],[
            'current_password.required'=>'Please enter current password',
            'new_password.required'=>'Please enter new password',
            'confirm_password.required'=>'Please enter confirm password'
        ]);

        $current_password=trim(strip_tags($request->input('current_password')));
        $new_password=trim(strip_tags($request->input('new_password')));
        $confirm_password=trim(strip_tags($request->input('confirm_password')));

        $aid=session('aid');
        $admin=Admin::find($aid);
        if($admin)
        {
            if(password_verify($current_password,$admin->password))
            {
                if($new_password==$confirm_password)
                {
                    try
                    {
                        $admin->password=password_hash($new_password,PASSWORD_DEFAULT);
                        $admin->save();
                        return back()->with('message','New password updated successfully');
                    }
                    catch(Exception $e)
                    {
                        return back()->with('message','Error to update password');
                    }
                }
                else
                {
                    return back()->with('message','New password and Confirm password not match');
                }
            }
            else
            {
                return back()->with('message','Current password not match');
            }
        }


    }


    //add session start

    public function view_session()
    {
        $data=Add_session::all();
        return view('admin.view_session',compact('data'));
    }
    public function add_session(Request $request)
    {
        $request->validate([
            'session_name'=>'required|numeric|regex:/^\d{4}$/|unique:add_sessions,session_name'
        ],[
            'session_name.required'=>'Please enter session name',
            'session_name.numeric'=>'Please enter numbers only',
            'session_name.regex'=>'Session name not valid (eg:-2012,2013 and etc..)'
        ]);

        $name=$request->input('session_name');

        $add_session=new Add_session();
        $add_session->session_name=$name;

        try
        {
        $add_session->save();
        return back()->with('message','Add session successfully');
        }
        catch(Exception $e)
        {
            return back()->with('message','Error to add session');
        }
    }
    public function delete_session(Request $request,$id)
    {

        try
        {
        Add_session::find($id)->delete();
        return back()->with('message','session deleted successfully');
        }
        catch(Exception $e)
        {
            return back()->with('message','Error to delete sessions');
        }
    }

    //add session end


    //add semester start

    public function view_semester()
    {
        $data=Add_semester::all();
        return view('admin.view_semester',compact('data'));
    }
    public function add_semester(Request $request)
    {
        $request->validate([
            'semester_name'=>'required|numeric|regex:/^\d{1,4}$/|unique:add_semesters,semester_name'
        ],[
            'semester_name.required'=>'Please enter Semester',
            'semester_name.numeric'=>'Please enter numbers only',
            'semester_name.regex'=>'semester not valid (eg:1,2,3 and etc..)'
        ]);

        $name=$request->input('semester_name');

        $add_semester=new Add_semester();
        $add_semester->semester_name=$name;

        try
        {
        $add_semester->save();
        return back()->with('message','Add semester successfully');
        }
        catch(Exception $e)
        {
            return back()->with('message','Error to add semester');
        }
    }
    public function delete_semester(Request $request,$id)
    {

        try
        {
        Add_semester::find($id)->delete();
        return back()->with('message','semester deleted successfully');
        }
        catch(Exception $e)
        {
            return back()->with('message','Error to delete semester');
        }
    }

    //add semester end


     //add department start

     public function view_department()
     {
         $data=Add_department::all();
         return view('admin.view_department',compact('data'));
     }
     public function add_department(Request $request)
     {
         $request->validate([
             'department_name'=>'required|string|regex:/^[a-zA-Z][a-zA-Z ]+$/|unique:add_departments,department_name'
         ],[
             'department_name.required'=>'Please enter Department',
             'department_name.regex'=>'department name not valid'
         ]);

         $name=$request->input('department_name');

         $add_department=new Add_department();
         $add_department->department_name=$name;

         try
         {
         $add_department->save();
         return back()->with('message','Add department successfully');
         }
         catch(Exception $e)
         {
             return back()->with('message','Error to add department');
         }
     }
     public function delete_department(Request $request,$id)
     {

         try
         {
         Add_department::find($id)->delete();
         return back()->with('message','department deleted successfully');
         }
         catch(Exception $e)
         {
             return back()->with('message','Error to delete department');
         }
     }

     //add department end


          //add course start

          public function view_course()
          {
              $data=Add_course::all();
              return view('admin.view_course',compact('data'));
          }
          public function edit_course($id)
          {
              $data=Add_course::find($id);
              return view('admin.edit_course',compact('data'));
          }
          public function add_course(Request $request)
          {
              $request->validate([
                  'course_code'=>'required|regex:/^[a-zA-Z0-9+]+$/|max:12',
                  'course_name'=>'required|string|regex:/^[a-zA-Z][a-zA-Z+ ]+$/|unique:add_courses,course_name',
                  'course_unit'=>'required|numeric|regex:/^\d{1,3}$/',
                  'seat_limit'=>'required|numeric|regex:/^\d{1,6}$/'
              ],[
                  'course_name.required'=>'Please enter Course name',
                  'course_name.regex'=>'Course name not valid'
              ]);

              $name=$request->input('course_name');
              $code=$request->input('course_code');
              $unit=$request->input('course_unit');
              $seat=$request->input('seat_limit');

              $add_course=new Add_course();
              $add_course->course_name=$name;
              $add_course->course_code=$code;
              $add_course->course_unit=$unit;
              $add_course->seat_limit=$seat;

              try
              {
              $add_course->save();
              return back()->with('message','Add course successfully');
              }
              catch(Exception $e)
              {
                  return back()->with('message','Error to add course');
              }
          }
          public function update_course(Request $request,$id)
          {
              $request->validate([
                  'course_code'=>'required|regex:/^[a-zA-Z0-9+]+$/|max:12',
                  'course_name'=>'required|string|regex:/^[a-zA-Z][a-zA-Z+ ]+$/|unique:add_courses,course_name',
                  'course_unit'=>'required|numeric|regex:/^\d{1,3}$/',
                  'seat_limit'=>'required|numeric|regex:/^\d{1,6}$/'
              ],[
                  'course_name.required'=>'Please enter Course name',
                  'course_name.regex'=>'Course name not valid'
              ]);

              $name=$request->input('course_name');
              $code=$request->input('course_code');
              $unit=$request->input('course_unit');
              $seat=$request->input('seat_limit');

              $add_course=Add_course::find($id);
              $add_course->course_name=$name;
              $add_course->course_code=$code;
              $add_course->course_unit=$unit;
              $add_course->seat_limit=$seat;

              try
              {
              $add_course->save();
              return redirect()->route('admin.view_course')->with('message','Course updated successfully');
              }
              catch(Exception $e)
              {
                  return redirect()->route('admin.view_course')->with('message','Error to update course');
              }
          }
          public function delete_course(Request $request,$id)
          {

              try
              {
              Add_course::find($id)->delete();
              return back()->with('message','course deleted successfully');
              }
              catch(Exception $e)
              {
                  return back()->with('message','Error to delete course');
              }
          }

          //add course end

    //registration add start
    public function add_student()
    {
        return view('admin.add_student');
    }
    public function register_student(Request $request)
    {
        $request->validate([
            'password'=>'required|regex:/^[a-zA-Z0-9$%#@!]+$/|max:12|min:8',
            'student_name'=>'required|string|regex:/^[a-zA-Z][a-zA-Z ]+$/',
            'reg_no'=>'required|numeric|regex:/^\d{8,15}$/|unique:students,reg_no'
        ],[
            'student_name.required'=>'Please enter Student name',
            'student_name.regex'=>'Student name not valid'
        ]);

        $student_name=$request->input('student_name');
        $reg_no=$request->input('reg_no');
        $password=$request->input('password');
        $add_student=new Student();
        $add_student->student_name=$student_name;
        $add_student->reg_no=$reg_no;
        $add_student->password=password_hash($password,PASSWORD_DEFAULT);



        try
        {
        $add_student->save();

        return back()->with('message','Add student successfully');
        }
        catch(Exception $e)
        {
            return back()->with('message','Error to add student');
        }
    }
    //registration add end

    //manage student start
    public function manage_student()
    {
        $data=Student::orderBy('student_name','asc')->get();
        return view('admin.manage_student',compact('data'));
    }
    public function delete_student(Request $request,$id)
    {

        try
        {
        Student::find($id)->delete();
        return back()->with('message','Student deleted successfully');
        }
        catch(Exception $e)
        {
            return back()->with('message','Error to delete Student');
        }
    }
    public function edit_student($id)
    {
        $data=Student::find($id);
        return view('admin.edit_student',compact('data'));
    }
    public function update_student(Request $request,$id)
    {
        $request->validate([
            'password'=>'required|regex:/^[a-zA-Z0-9$%#@!]+$/|max:12|min:8',
            'student_name'=>'required|string|regex:/^[a-zA-Z][a-zA-Z ]+$/',
            'reg_no'=>'required|numeric|regex:/^\d{8,15}$/|unique:students,reg_no,'.$id
        ],[
            'student_name.required'=>'Please enter Student name',
            'student_name.regex'=>'Student name not valid'
        ]);

        $student_name=$request->input('student_name');
        $reg_no=$request->input('reg_no');
        $password=$request->input('password');
        $add_student=Student::find($id);
        $add_student->student_name=$student_name;
        $add_student->reg_no=$reg_no;
        $add_student->password=password_hash($password,PASSWORD_DEFAULT);

        try
        {
        $add_student->save();
        return redirect()->route('admin.manage_student')->with('message','Update student successfully');
        }
        catch(Exception $e)
        {
            return redirect()->route('admin.manage_student')->with('message','Error to update student');
        }
    }
    //manage student end


    //enroll history start
    public function enroll_history()
    {
        $data=DB::select('select f.id as sid,f.student_name,f.reg_no,a.image_path,a.id,a.level_id,a.created_at,b.session_name,c.course_unit,c.course_code,c.course_name,d.department_name,e.semester_name from add_enrolls as a left join add_sessions as b on a.session_id=b.id left join add_courses as c on a.course_id=c.id left join add_departments as d on a.department_id=d.id left join add_semesters as e on a.semester_id=e.id left join students as f on a.student_id=f.id', []);
        return view('admin.enroll_history',compact('data'));
    }
    public function print_fun($aid,$sid)
    {
        $student=Student::find($sid);
        $data=DB::select('select a.image_path,a.id,a.level_id,a.created_at,b.session_name,c.course_unit,c.course_code,c.course_name,d.department_name,e.semester_name from add_enrolls as a left join add_sessions as b on a.session_id=b.id left join add_courses as c on a.course_id=c.id left join add_departments as d on a.department_id=d.id left join add_semesters as e on a.semester_id=e.id where a.student_id=? and a.id=?', [$sid,$aid]);
        return view('student.print',compact('data','student'));
    }
    //enroll history end

    //student log start
    public function student_log()
    {
        $data=Studentlog::orderBy('id','desc')->get();
        return view('admin.student_log',compact('data'));
    }
    //student log end

    //add news start
    public function add_news()
    {
        $data=Add_news::all();
        return view('admin.add_news',compact('data'));
    }
    public function register_news(Request $request)
    {
        $request->validate([
            'news_description'=>'required|regex:/^[a-zA-Z0-9,#.\s+]+$/|max:150',
            'news_title'=>'required|string|regex:/^[a-zA-Z][a-zA-Z ]+$/|max:50'
        ],[
            'news_title.required'=>'Please enter News title',
            'news_title.regex'=>'News title not valid'
        ]);

        $news_title=$request->input('news_title');
        $news_description=$request->input('news_description');

        $add_news=new Add_news();
        $add_news->news_title=$news_title;
        $add_news->news_description=$news_description;

        try
        {
        $add_news->save();
        return back()->with('message','Add News successfully');
        }
        catch(Exception $e)
        {
            return back()->with('message','Error to add news');
        }
    }
    public function delete_news(Request $request,$id)
    {

        try
        {
        Add_news::find($id)->delete();
        return back()->with('message','News deleted successfully');
        }
        catch(Exception $e)
        {
            return back()->with('message','Error to delete News');
        }
    }
    //add news end



    public function logout()
    {
        Session::forget('aid');
        return redirect()->route('admin_login');
    }
}

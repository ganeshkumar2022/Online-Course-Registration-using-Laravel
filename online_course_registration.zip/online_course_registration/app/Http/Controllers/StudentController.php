<?php

namespace App\Http\Controllers;

use App\Models\Add_course;
use App\Models\Add_department;
use App\Models\Add_enroll;
use App\Models\Add_semester;
use App\Models\Add_session;
use App\Models\Student;
use App\Models\Studentlog;
use Exception;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class StudentController extends Controller
{
    public function profile_change()
    {
        $sid=session('sid');
        $student_data=Student::find($sid);
        return view('student.profile_change',compact('student_data'));
    }

    public function update_profile(Request $request)
    {
        $request->validate([
            'student_name'=>'required|string|regex:/^[a-zA-Z][a-zA-Z ]+$/|max:30',
            'myimage'=>'required|image|mimes:jpeg,jpg,png,svg+xml|max:200'
        ],[
            'session_data.numeric'=>'Session name not valid',
            'department.numeric'=>'Department name not valid',
            'level.numeric'=>'Level format not valid',
            'semester.numeric'=>'Semester name not valid',
            'course.numeric'=>'Course name not valid',
            'myimage.required'=>'Please choose student photo',
            'myimage.image'=>'Student photo must be an image file'
        ]);

        $student_name=$request->input('student_name');
        $sid=session('sid');

        $add_enroll=Student::find($sid);
        $add_enroll->student_name=$student_name;


        if($files=$request->file('myimage'))
        {
            $name=$files->getClientOriginalName();
            $files->move('profile_images',$name);
            $add_enroll->image_path=$name;
        }

        try
        {
            $add_enroll->save();
            return redirect()->route('student.profile_change')->with('message','Profile Updated Successfully');
        }
        catch(Exception $e)
        {
            //return $e->getMessage();
            return redirect()->route('student.profile_change')->with('message','Error to Update a Profile');
        }

    }

    public function add_enroll()
    {
        $session_data=Add_session::orderBy('session_name','desc')->get();
        $department=Add_department::all();
        $course=Add_course::all();
        $semester=Add_semester::orderBy('semester_name','asc')->get();

        $sid=session('sid');
        $student_data=Student::find($sid);
        return view('student.add_enroll',compact('session_data','department','course','semester','student_data'));
    }

    public function register_enroll(Request $request)
    {
        $request->validate([
            'student_name'=>'required|string|regex:/^[a-zA-Z][a-zA-Z ]+$/|max:30',
            'reg_no'=>'required|numeric|regex:/^\d{8,15}$/',
            'session_data'=>'required|numeric',
            'department'=>'required|numeric',
            'level'=>'required|numeric',
            'semester'=>'required|numeric',
            'course'=>'required|numeric',
            'myimage'=>'required|image|mimes:jpeg,jpg,png,svg+xml|max:200'
        ],[
            'session_data.numeric'=>'Session name not valid',
            'department.numeric'=>'Department name not valid',
            'level.numeric'=>'Level format not valid',
            'semester.numeric'=>'Semester name not valid',
            'course.numeric'=>'Course name not valid',
            'myimage.required'=>'Please choose student photo',
            'myimage.image'=>'Student photo must be an image file'
        ]);

        $student_name=$request->input('student_name');
        $reg_no=$request->input('reg_no');
        $session_data=$request->input('session_data');
        $department=$request->input('department');
        $level=$request->input('level');
        $semester=$request->input('semester');
        $course=$request->input('course');
        $sid=session('sid');

        $add_enroll=new Add_enroll();
        $add_enroll->student_name=$student_name;
        $add_enroll->reg_no=$reg_no;
        $add_enroll->student_id=$sid;
        $add_enroll->session_id=$session_data;
        $add_enroll->department_id=$department;
        $add_enroll->semester_id=$semester;
        $add_enroll->course_id=$course;
        $add_enroll->level_id=$level;


        if($files=$request->file('myimage'))
        {
            $name=$files->getClientOriginalName();
            $files->move('enroll_images',$name);
            $add_enroll->image_path=$name;
        }

        try
        {
            $add_enroll->save();
            return redirect()->route('student.add_enroll')->with('message','Course Enrolled Successfully');
        }
        catch(Exception $e)
        {
            //return $e->getMessage();
            return redirect()->route('student.add_enroll')->with('message','Error to Enroll Course');
        }

    }

    //change password start
    public function change_password()
    {
        return view('student.change_password');
    }
    public function update_password(Request $request)
    {
        $request->validate([
            'current_password'=>'required',
            'new_password'=>['required','string','min:8','regex:/^[a-zA-Z\d]{8,}$/'],
            'confirm_password'=>'required'
        ],[
            'current_password.required'=>'Please enter current password',
            'new_password.required'=>'Please enter new password',
            'confirm_password.required'=>'Please enter confirm password'
        ]);

        $current_password=trim(strip_tags($request->input('current_password')));
        $new_password=trim(strip_tags($request->input('new_password')));
        $confirm_password=trim(strip_tags($request->input('confirm_password')));

        $aid=session('sid');
        $student=Student::find($aid);
        if($student)
        {
            if(password_verify($current_password,$student->password))
            {
                if($new_password==$confirm_password)
                {
                    try
                    {
                        $student->password=password_hash($new_password,PASSWORD_DEFAULT);
                        $student->save();
                        return back()->with('message','New password updated successfully');
                    }
                    catch(Exception $e)
                    {
                        return back()->with('message','Error to update password');
                    }
                }
                else
                {
                    return back()->with('message','New password and Confirm password not match');
                }
            }
            else
            {
                return back()->with('message','Current password not match');
            }
        }


    }

    //change password end

    public function view_enroll()
    {
        $sid=session('sid');
        $data=DB::select('select a.id,a.level_id,a.created_at,b.session_name,c.course_name,d.department_name,e.semester_name from add_enrolls as a left join add_sessions as b on a.session_id=b.id left join add_courses as c on a.course_id=c.id left join add_departments as d on a.department_id=d.id left join add_semesters as e on a.semester_id=e.id where a.student_id=?', [$sid]);
        return view('student.view_enroll',compact('data'));
    }
    public function print_fun($aid)
    {
        $sid=session('sid');
        $student=Student::find($sid);
        $data=DB::select('select a.image_path,a.id,a.level_id,a.created_at,b.session_name,c.course_unit,c.course_code,c.course_name,d.department_name,e.semester_name from add_enrolls as a left join add_sessions as b on a.session_id=b.id left join add_courses as c on a.course_id=c.id left join add_departments as d on a.department_id=d.id left join add_semesters as e on a.semester_id=e.id where a.student_id=? and a.id=?', [$sid,$aid]);
        return view('student.print',compact('data','student'));
    }
    public function logout()
    {
        $id=session('log_id');
        $logs=Studentlog::find($id);
        $logs->logout_time=date("d-m-Y h:i:sa");
        $logs->save();

        session()->forget('log_id');
        session()->forget('sid');
        return redirect()->route('student_login');
    }
}

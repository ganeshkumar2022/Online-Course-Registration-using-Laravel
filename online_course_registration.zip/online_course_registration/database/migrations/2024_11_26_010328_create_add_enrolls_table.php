<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('add_enrolls', function (Blueprint $table) {
            $table->id();
            $table->integer('student_id');
            $table->string('student_name');
            $table->string('reg_no');
            $table->string('image_path');
            $table->integer('session_id');
            $table->integer('department_id');
            $table->integer('level_id');
            $table->integer('semester_id');
            $table->integer('course_id');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('add_enrolls');
    }
};
